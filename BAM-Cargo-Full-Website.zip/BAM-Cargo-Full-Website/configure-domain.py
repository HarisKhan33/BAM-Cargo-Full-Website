"""Prepare static canonical/social URLs and sitemap for your actual HTTPS domain."""
from pathlib import Path
from urllib.parse import urlparse,urljoin
import html,re,sys,json
root=Path(__file__).resolve().parent
if len(sys.argv)!=2:raise SystemExit('Usage: python configure-domain.py https://your-actual-domain.com/')
domain=sys.argv[1].rstrip('/')+'/'
parsed=urlparse(domain)
if parsed.scheme!='https' or not parsed.netloc or parsed.query or parsed.fragment:raise SystemExit('Use your actual HTTPS website URL, without a query or fragment.')
pages=[]
for path in root.glob('*.html'):
 text=path.read_text()
 text=re.sub(r'<link\b[^>]*rel=["\']canonical["\'][^>]*>','',text)
 text=re.sub(r'<meta\b[^>]*property=["\']og:url["\'][^>]*>','',text)
 url=urljoin(domain,'' if path.name=='index.html' else path.name)
 if path.name not in ['404.html','search.html']:
  tags='<link rel="canonical" href="'+html.escape(url,quote=True)+'"><meta property="og:url" content="'+html.escape(url,quote=True)+'">'
  text=text.replace('</head>',tags+'</head>');pages.append(url)
 def image(m):
  current=m.group(2)
  if not current.startswith('https://'):current=urljoin(domain,current)
  return m.group(1)+html.escape(current,quote=True)+m.group(3)
 text=re.sub(r'(<meta\b[^>]*(?:property|name)="(?:og:image|twitter:image)"[^>]*content=")([^"]*)("[^>]*>)',image,text)
 path.write_text(text)
(root/'sitemap.xml').write_text('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'+''.join('<url><loc>'+html.escape(url)+'</loc></url>' for url in sorted(pages))+'</urlset>\n')
(root/'robots.txt').write_text('User-agent: *\nAllow: /\nDisallow: /search.html\nSitemap: '+urljoin(domain,'sitemap.xml')+'\n')
path=root/'config.js';text=path.read_text();text=re.sub(r'publicUrl:\s*"[^"]*"','publicUrl: '+json.dumps(domain),text);path.write_text(text)
print('Updated',len(pages),'page URLs. Upload the website files to your host.')
