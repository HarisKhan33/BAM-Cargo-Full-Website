# BAM Cargo Services — Complete Website

## Open the website now

1. Extract the complete ZIP to a folder.
2. Double-click **index.html**. Keep the `assets` folder and `config.js` beside it.
3. Use the menus to explore the complete pages. You do not need WordPress, Node.js or a build command for this browser version.

All imagery and fonts are included locally. The website includes Home, About, Services, six service-detail pages, Gallery, three Cargo Insights articles, FAQ, Contact, a full quote form, shipment support, search, privacy/terms and a styled 404 page. It works on phones, tablets and desktops.

## Add real business details

Open **config.js** in Notepad or another text editor. Enter your actual WhatsApp number in international digits, company phone, email, office address, hours, and map link. Save it and refresh the website.

```js
whatsapp: "YOUR_ACTUAL_INTERNATIONAL_DIGITS",
phone: "YOUR_ACTUAL_PHONE",
email: "YOUR_ACTUAL_EMAIL",
address: "YOUR_ACTUAL_OFFICE_ADDRESS",
```

The placeholders above are instructions; they are not prefilled in the website. No real BAM contact information was supplied. Until a valid number is entered, the forms explain that WhatsApp inquiries are unavailable. Quote and contact forms prepare a WhatsApp message; you review and send it in WhatsApp. They do not send email, collect payments or store inquiries in a database.

For tracking, enter your real carrier HTTPS URL in `trackingUrl` with `{tracking_id}` where the ID belongs. Without one, the site provides a truthful support message and can prepare a WhatsApp update request. There is no connected live cargo database or fabricated shipment status.

You can upload your own logo to `assets/images/` and set `logo` to its relative filename. The bundled text wordmark is an original BAM placeholder identity, not a reproduction of an unavailable official logo. Edit the page HTML files to change copy or images.

Optional genuine reviews and partner logos can be entered in `config.js`; those sections stay hidden when their arrays are empty. Never publish invented business statistics, reviews or partnerships. Supplied gallery images are clearly labeled illustrative; replace them with approved company photography when available.

## Install the complete WordPress version

1. Install WordPress on your hosting account if it is not already available.
2. Open **Appearance → Themes → Add New → Upload Theme**.
3. Select **wordpress/BAM-Cargo-Complete-WordPress.zip**, install and activate it.
4. Open **Appearance → BAM Theme Setup** and choose **Install Complete Website Pages & Illustrative Content**.
5. Enter your business details under **Appearance → Customize → BAM Website Settings** and upload the real logo under **Site Identity**.
6. Save **Settings → Permalinks → Post name**. Review the generated articles, offered services and draft privacy/terms pages.

The full installer creates missing pages, six services, three authored cargo-planning articles and four illustrative gallery entries. It imports the bundled images into WordPress Media. Existing content is preserved. It selects Home and Cargo Insights in Reading settings and assigns a new menu only when one is not already assigned. Policies remain drafts until reviewed; publish the actual policies and select the privacy page under Settings → Privacy.

After installation, you can manage content through WordPress without source-code edits. Blog posts use the standard editor; Services, FAQs, Operations Gallery, Customer Reviews and Partners have editing menus. No Elementor or paid plugin is required.

The WordPress theme ZIP is an installation component of this complete package. Upload that inner ZIP to WordPress, not the outer full-website ZIP. WordPress software, hosting credentials and a production database are not included.

## Hosting the browser version

Upload the files in this folder to your static hosting account or web server, keeping their relative paths. This package is not yet published at a live internet address.

Before hosting under your real domain, run the optional helper from this folder if Python is available:

```bash
python configure-domain.py https://your-actual-domain.com/
```

It generates canonical URLs, absolute social images, `sitemap.xml` and the sitemap reference in `robots.txt`. It does not upload files or register a domain. On WordPress, use your chosen SEO plugin and core/plugin sitemap instead. Configure the host to serve `404.html` for missing static paths.

## Included behavior

- Local Poppins and Playfair Display fonts; WebP imagery.
- Dark/light appearance, saved locally where browser storage permits.
- Sticky mobile navigation and floating WhatsApp/appearance controls.
- Accessible native FAQ accordions.
- Category gallery filters, image lightbox, arrows, Escape and swipe.
- Search across the included pages and articles.
- Validated quote and contact forms with encoded WhatsApp messages.
- SEO metadata, social-preview card and optional actual-domain setup.

Static pages do not include a CMS login, email delivery, pricing engine, shipment API, payment gateway, customer accounts or a lead database. The WordPress version supplies the content-management interface. An email form can be connected there through a configured form-plugin shortcode.

Code is GPL-2.0-or-later. Font licenses and asset provenance are included. No production WhatsApp message was sent during testing.
