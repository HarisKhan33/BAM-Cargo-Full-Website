# Included asset record

Four original illustrative cargo images were generated for this project with the built-in Image Generation tool, then exported as WebP for website use. They are not photographs of real BAM Cargo facilities or vehicles. Final theme paths:

- `assets/images/hero.webp`: Dubai blue-hour port, dark left negative space, warm-lit container ship/cranes on the right, distant skyline; cinematic realism; no text or logos.
- `assets/images/warehouse.webp`: organized warehouse racks and pallets, charcoal shadows and warm gold lights; no text or logos.
- `assets/images/air.webp`: unbranded cargo aircraft and pallets at a Dubai-style airport in evening light; no text or logos.
- `assets/images/road.webp`: unbranded freight truck on a highway with distant Dubai skyline in evening light; no text or logos.

Generation prompts requested realistic illustrative logistics imagery, cinematic dark-and-gold lighting, and no company markings or watermarks. Hero composition was wide, other subjects 4:3. These are illustrative generated locations, not precise representations of actual infrastructure.

`social-preview.jpg` is a code-rendered brand-sharing card. `screenshot.png` is captured from the theme's actual WordPress homepage. Icons and text wordmark are original inline SVG/HTML code.

Poppins and Playfair Display are locally bundled Google Fonts distributions under their included SIL Open Font Licenses. Source: Google Fonts official stylesheet and https://github.com/google/fonts/tree/main/ofl/.
