(() => {
 'use strict';
 const config=window.bamConfig||{};
 const root=document.documentElement;
 const toggle=document.querySelector('.appearance-toggle');
 let stored; try { stored=localStorage.getItem('bam-appearance'); } catch {}
 const system=window.matchMedia('(prefers-color-scheme:light)');
 const initial=root.dataset.theme;
 const setTheme=(mode)=>{root.dataset.theme=mode;toggle?.setAttribute('aria-pressed',String(mode==='light'));};
 setTheme(stored==='light'||stored==='dark'?stored:(initial==='system'?(system.matches?'light':'dark'):initial));
 toggle?.addEventListener('click',()=>{const next=root.dataset.theme==='light'?'dark':'light';setTheme(next);try{localStorage.setItem('bam-appearance',next);stored=next;}catch{}});
 system.addEventListener?.('change',()=>{if(!stored&&initial==='system'){setTheme(system.matches?'light':'dark');}});
 const menuButton=document.querySelector('.menu-toggle');
 const nav=document.querySelector('.site-nav');
 const closeMenu=()=>{nav?.classList.remove('is-open');menuButton?.setAttribute('aria-expanded','false');};
 menuButton?.addEventListener('click',()=>{const open=nav.classList.toggle('is-open');menuButton.setAttribute('aria-expanded',String(open));});
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&nav?.classList.contains('is-open')){closeMenu();menuButton.focus();}});
 document.addEventListener('click',e=>{if(!e.target.closest('.site-header')){closeMenu();}});
 nav?.addEventListener('click',e=>{if(e.target.closest('a')){closeMenu();}});
 const validNumber=()=>/^\d{7,15}$/.test(config.number||'');
 const whatsApp=(message)=>'https://wa.me/'+config.number+'?text='+encodeURIComponent(message);
 document.querySelectorAll('[data-whatsapp-form]').forEach(form=>{
  form.addEventListener('submit',e=>{
   e.preventDefault();const status=form.querySelector('.form-status');
   if(!form.reportValidity()){return;}
   if(!validNumber()){status.textContent=config.missing;return;}
   const isQuote=form.dataset.whatsappForm==='quote';
   const lines=['Hello '+config.company+',',isQuote?config.quoteHeading:config.contactHeading,''];
   form.querySelectorAll('[data-label]').forEach(field=>{if(field.value.trim()){lines.push(field.dataset.label+': '+field.value.trim());}});
   // Navigate directly on user submission. The user reviews and sends inside WhatsApp.
   window.location.assign(whatsApp(lines.join('\n')));
  });
 });
 document.querySelectorAll('.tracking-form').forEach(form=>{
  form.addEventListener('submit',e=>{
   e.preventDefault();if(!form.reportValidity()){return;}
   const id=form.elements.tracking.value.trim();const card=form.closest('.tracking-card');
   const status=card.querySelector('.tracking-status');const update=card.querySelector('.tracking-update');
   if(config.trackingUrl&&config.trackingUrl.includes('{tracking_id}')){
    try{const url=new URL(config.trackingUrl.replaceAll('{tracking_id}',encodeURIComponent(id)));if(url.protocol==='https:'){window.location.assign(url.href);return;}}catch{}
   }
   status.textContent=config.trackingMissing;
   if(validNumber()){update.href=whatsApp(config.trackingHeading+' '+id);}else{status.textContent+=' '+config.missing;}
  });
 });
 const dialog=document.querySelector('.lightbox');
 const galleryItems=[...document.querySelectorAll('.gallery-item')];
 let current=0,opener=null,startX=0;
 const visibleItems=()=>galleryItems.filter(item=>!item.hidden);
 const showImage=(index)=>{const items=visibleItems();if(!items.length){return;}current=(index+items.length)%items.length;const item=items[current];const img=dialog.querySelector('img');img.src=item.dataset.full;img.alt=item.dataset.caption;dialog.querySelector('figcaption').textContent=item.dataset.caption+' · '+(current+1)+' / '+items.length;};
 galleryItems.forEach(item=>item.addEventListener('click',()=>{if(!dialog?.showModal){window.location.assign(item.dataset.full);return;}opener=item;showImage(visibleItems().indexOf(item));dialog.showModal();document.body.classList.add('lightbox-open');}));
 dialog?.querySelector('.lightbox-close')?.addEventListener('click',()=>dialog.close());
 dialog?.querySelector('.lightbox-prev')?.addEventListener('click',()=>showImage(current-1));
 dialog?.querySelector('.lightbox-next')?.addEventListener('click',()=>showImage(current+1));
 dialog?.addEventListener('close',()=>{document.body.classList.remove('lightbox-open');opener?.focus();});
 dialog?.addEventListener('click',e=>{if(e.target===dialog){dialog.close();}});
 dialog?.addEventListener('keydown',e=>{if(e.key==='ArrowLeft'||e.key==='ArrowRight'){e.preventDefault();showImage(current+(e.key==='ArrowRight'?1:-1));}});
 dialog?.addEventListener('touchstart',e=>{startX=e.changedTouches[0].screenX;},{passive:true});
 dialog?.addEventListener('touchend',e=>{const delta=e.changedTouches[0].screenX-startX;if(Math.abs(delta)>50){showImage(current+(delta<0?1:-1));}},{passive:true});
 document.querySelectorAll('[data-gallery-filter]').forEach(button=>button.addEventListener('click',()=>{
  document.querySelectorAll('[data-gallery-filter]').forEach(b=>b.setAttribute('aria-pressed',String(b===button)));
  galleryItems.forEach(item=>{item.hidden=button.dataset.galleryFilter!=='all'&&!item.dataset.categories.split(' ').includes(button.dataset.galleryFilter);});
 }));
 const reviews=document.querySelector('.reviews-track');
 document.querySelectorAll('[data-review-dir]').forEach(b=>b.addEventListener('click',()=>{const dir=(root.dir==='rtl'?-1:1)*Number(b.dataset.reviewDir);reviews?.scrollBy({left:dir*reviews.clientWidth*.85,behavior:window.matchMedia('(prefers-reduced-motion:reduce)').matches?'instant':'smooth'});}));
})();
