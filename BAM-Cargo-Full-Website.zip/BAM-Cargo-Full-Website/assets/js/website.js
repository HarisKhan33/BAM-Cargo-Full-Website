(() => {
 'use strict';
 const data=window.BAM_SITE||{};
 const file=location.pathname.split('/').pop()||'index.html';
 const servicePages=['air-freight.html','sea-freight.html','road-freight.html','door-to-door.html','warehousing.html','customs-clearance.html','all-services.html'];
 const journalPages=['air-or-sea-freight.html','prepare-a-cargo-quote.html','packing-for-the-journey.html'];
 const active=servicePages.includes(file)?'services.html':journalPages.includes(file)?'blog.html':file;
 document.querySelectorAll('.site-nav li').forEach(li=>li.classList.remove('current-menu-item','current_page_item'));
 document.querySelectorAll('.site-nav a,.mobile-bottom a').forEach(a=>{a.removeAttribute('aria-current');if(a.getAttribute('href')===active){a.setAttribute('aria-current','page');a.closest('li')?.classList.add('current-menu-item');}});
 const number=(data.whatsapp||'').replace(/\D/g,'');
 const valid=/^\d{7,15}$/.test(number);
 const safeHttps=value=>{try{const url=new URL(value);return url.protocol==='https:'?url.href:'';}catch{return '';}};
 const appendText=(parent,tag,text,cls)=>{const node=document.createElement(tag);node.textContent=text;if(cls)node.className=cls;parent.appendChild(node);return node;};
 document.querySelectorAll('[data-company]').forEach(node=>{node.textContent=data.company||'BAM Cargo Services';});
 document.querySelectorAll('[data-whatsapp]').forEach(link=>{
  if(valid){const service=link.closest('.service-card')?.querySelector('h3')?.textContent.trim();const message='Hello '+(data.company||'BAM Cargo Services')+', I need a cargo quote'+(service?' for '+service:'')+'.';link.href='https://wa.me/'+number+'?text='+encodeURIComponent(message);}
  else{link.href='contact.html';}
 });
 const tracking=document.querySelector('.tracking-update');if(tracking&&valid){tracking.href='https://wa.me/'+number+'?text='+encodeURIComponent('Hello, I need a shipment update.');}
 const logo=data.logo;
 if(logo&&!/^\w+:/.test(logo)&&!logo.startsWith('//')){const anchor=document.querySelector('.brand>a');if(anchor){anchor.replaceChildren();const img=appendText(anchor,'img','');img.src=logo;img.alt=data.company||'BAM Cargo Services';img.className='custom-logo';}}
 document.querySelectorAll('[data-contact-details]').forEach(container=>{
  for(const [key,label] of Object.entries({phone:'Phone',email:'Email',address:'Office',hours:'Opening hours'})){
   if(!data[key])continue;
   const item=document.createElement('div');item.className='configured-contact';container.appendChild(item);
   appendText(item,'span',label,'eyebrow');
   if(key==='phone'){const a=appendText(item,'a',data[key]);a.href='tel:'+String(data[key]).replace(/[^+\d]/g,'');}
   else if(key==='email'){const a=appendText(item,'a',data[key]);a.href='mailto:'+data[key];}
   else appendText(item,'p',data[key]);
  }
  if(safeHttps(data.mapUrl)){const p=document.createElement('p');container.appendChild(p);const a=appendText(p,'a','View our office on Google Maps ↗','text-link');a.href=safeHttps(data.mapUrl);}
 });
 const footer=document.querySelector('.footer-grid>div:last-child');
 const footerCompany=document.querySelector('.footer-grid>div:first-child>p');if(footerCompany&&data.company)footerCompany.textContent=data.company;
 if(footer){['address','phone','email','hours'].reverse().forEach(key=>{if(data[key]){const p=document.createElement('p');p.textContent=data[key];footer.insertBefore(p,footer.querySelector('a'));}});}
 if(safeHttps(data.publicUrl)&&location.protocol.startsWith('http')){
  const url=new URL(location.pathname.split('/').pop()||'index.html',data.publicUrl.endsWith('/')?data.publicUrl:data.publicUrl+'/').href;
  if(!document.querySelector('link[rel="canonical"]')){const canonical=document.createElement('link');canonical.rel='canonical';canonical.href=url;document.head.appendChild(canonical);}
  if(!document.querySelector('meta[property="og:url"]')){const meta=document.createElement('meta');meta.setAttribute('property','og:url');meta.content=url;document.head.appendChild(meta);}
 }
 const main=document.querySelector('main');
 if(main&&Array.isArray(data.reviews)&&data.reviews.length){
  const section=document.createElement('section');section.className='section reviews-section';
  section.innerHTML='<div class="container"><p class="eyebrow">OUR CUSTOMERS’ EXPERIENCES</p><div class="section-heading"><h2>Our customers’ words.</h2><div class="carousel-controls"><button type="button" data-review-dir="-1" aria-label="Previous review">←</button><button type="button" data-review-dir="1" aria-label="Next review">→</button></div></div><div class="reviews-track" tabindex="0" role="region" aria-label="Customer reviews"></div></div>';
  const track=section.querySelector('.reviews-track');
  data.reviews.forEach(review=>{if(!review.name||!review.text)return;const article=document.createElement('article');article.className='review-card';track.appendChild(article);const rating=Number(review.rating);if(Number.isInteger(rating)&&rating>=1&&rating<=5){const stars=appendText(article,'div','★'.repeat(rating),'stars');stars.setAttribute('aria-label',rating+' out of 5 stars');}appendText(article,'blockquote',review.text);appendText(article,'strong',review.name);appendText(article,'p',[review.location,review.service].filter(Boolean).join(' · '),'muted');});
  if(track.children.length)main.appendChild(section);
 }
 if(main&&Array.isArray(data.partners)&&data.partners.length){
  const section=document.createElement('section');section.className='partners-section';section.innerHTML='<div class="container"><p class="eyebrow">TRUSTED PARTNERS</p><div class="partners-grid"></div></div>';
  const grid=section.querySelector('.partners-grid');data.partners.forEach(partner=>{if(!partner.name)return;const card=document.createElement('div');grid.appendChild(card);if(partner.logo&&!/^\w+:/.test(partner.logo)&&!partner.logo.startsWith('//')){const img=appendText(card,'img','');img.src=partner.logo;img.alt=partner.name;img.loading='lazy';}else appendText(card,'span',partner.name);});if(grid.children.length)main.appendChild(section);
 }
 document.querySelectorAll('.search-form').forEach(form=>form.addEventListener('submit',event=>{event.preventDefault();const query=form.querySelector('input').value.trim();if(query)location.href='search.html?q='+encodeURIComponent(query);}));
 const results=document.querySelector('#search-results');
 if(results){const query=new URLSearchParams(location.search).get('q')||'';const input=document.querySelector('.search-form input');input.value=query;const matches=(window.bamSearchData||[]).filter(item=>!query||[item.title,item.summary].join(' ').toLowerCase().includes(query.toLowerCase())).filter(item=>item.url!=='404.html');document.querySelector('.search-count').textContent=matches.length+' result'+(matches.length===1?'':'s')+(query?' for “'+query+'”':'');matches.forEach(item=>{const article=document.createElement('article');article.className='post-card form-card';results.appendChild(article);const h=appendText(article,'h2','');const a=appendText(h,'a',item.title);a.href=item.url;appendText(article,'p',item.summary,'muted');const read=appendText(article,'a','Explore page ↗','text-link');read.href=item.url;});}
})();
