/* Edit this single file with your verified business details. No build command is needed. */
window.BAM_SITE = {
 company: "BAM Cargo Services",
 whatsapp: "", // International digits only, e.g. 923001234567. Enter your actual business number.
 phone: "",
 email: "",
 address: "",
 hours: "",
 mapUrl: "", // Your genuine HTTPS Google Maps location URL.
 logo: "", // Optional local image path, e.g. assets/images/my-logo.png.
 trackingUrl: "", // Actual carrier HTTPS URL containing {tracking_id}.
 publicUrl: "", // Your real website URL after hosting, e.g. https://your-domain.com/.
 // Add only reviews approved by the business and customer. Keep empty to hide.
 reviews: [], // {name:"", text:"", location:"", service:"", rating:5}
 partners: [] // {name:"", logo:"assets/images/partner.png"}; genuine relationships only.
};
window.bamConfig = {
 number: (window.BAM_SITE.whatsapp || "").replace(/\D/g, ""),
 company: window.BAM_SITE.company,
 trackingUrl: window.BAM_SITE.trackingUrl,
 missing: "WhatsApp inquiries are not available yet. Please use the contact details provided by the cargo team.",
 trackingMissing: "Online shipment tracking is currently being configured. Please contact our team on WhatsApp for the latest shipment information.",
 quoteHeading: "I need a cargo quote.",
 contactHeading: "I have a cargo inquiry.",
 trackingHeading: "Please provide a shipment update for tracking ID:"
};
